import argparse

def arg_parse():
        parser = argparse.ArgumentParser(description='DCGCL Arguments.')
        parser.add_argument('--DS', dest='DS', help='Dataset', default='uk')
        return parser.parse_args()

