import torch
import torch.nn.functional as F
from sklearn.metrics import *
from scipy import interpolate
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
class Metric():

    @staticmethod
    def ACC(output, label):
        with torch.no_grad():
            pred = torch.argmax(output, dim=1)
            correct = (pred == label)
            total_acc = correct.sum().item() / len(output)  
            print(f"total acc is: {total_acc}")
    
    @staticmethod
    def F1_score(output, label):
        with torch.no_grad():
            pred = torch.argmax(output, dim=1)
            f1 = f1_score(label.cpu().numpy(), pred.cpu().numpy(), average='macro')
            print(f"F1_score is: {f1}")

    @staticmethod
    def Recall(output, label):
        with torch.no_grad():
            pred = torch.argmax(output, dim=1)
            recall = recall_score(label.cpu().numpy(), pred.cpu().numpy(), average='macro')
            print(f"recall is: {recall}")

    @staticmethod
    def Precision(output, label):
        with torch.no_grad():
            pred = torch.argmax(output, dim=1)
            precision = precision_score(label.cpu().numpy(), pred.cpu().numpy(), average='macro')
            print(f"precision is: {precision}")

    @staticmethod
    def Each_Class_ACC(output, label):
        with torch.no_grad():
            pred = torch.argmax(output, dim=1)

        # 获取类别总数
        num_classes = torch.max(torch.cat([pred, label])) + 1  # 假设类别是从 0 开始的

        # 初始化准确率计算变量
        accuracies = torch.zeros(num_classes)
        counts = torch.zeros(num_classes)

        # 遍历所有类别
        for i in range(num_classes):
            # 找到该类别对应的索引
            mask = (label == i)
            # 计算该类别的准确率
            correct = (pred[mask] == label[mask]).sum().item()
            total = mask.sum().item()
            if total > 0:  # 避免除以零
                accuracies[i] = correct / total
            counts[i] = total


        # 打印每个类别的准确率
        for i in range(num_classes):
            print(f"类别 {i} 的准确率: {accuracies[i]:.2f}，样本数: {counts[i]:.0f}")


        
    # @staticmethod
    # def ACC(output,target,u=None,region_len= 1):
    #     with torch.no_grad():
    #         pred = torch.argmax(output,dim=1)
    #         correct = (pred==target)
    #         region_correct = (pred/region_len).long()==(target/region_len).long()
    #     acc = correct.sum().item()/len(target)
    #     region_acc = region_correct.sum().item()/len(target)
    #     split_acc = [0,0,0,0]

    #     # count number of classes for each region
    #     num_class = int(4*region_len)
    #     region_idx = (torch.arange(num_class)/region_len).long()
    #     region_vol = [
    #         num_class-torch.count_nonzero(region_idx).item(),
    #         torch.where(region_idx==1,True,False).sum().item(),
    #         torch.where(region_idx==2,True,False).sum().item(),
    #         torch.where(region_idx==3,True,False).sum().item()
    #     ]
    #     target_count = target.bincount().cpu().numpy()
    #     region_vol = [
    #         target_count[:region_vol[0]].sum(), 
    #         target_count[region_vol[0]:(region_vol[0]+region_vol[1])].sum(),
    #         target_count[region_vol[1]:(region_vol[1]+region_vol[2])].sum(),
    #         target_count[-region_vol[3]:].sum()]
    #     for i in range(len(target)):
    #         split_acc[region_idx[target[i].item()]] += correct[i].item()
    #     split_acc = [split_acc[i]/region_vol[i] for i in range(4)]

    #     print('Classification ACC:')
    #     print('\t all \t =',acc)
    #     print('\t 0 \t =',split_acc[0])
    #     print('\t 1 \t =',split_acc[1])
    #     print('\t 2 \t =',split_acc[2])
    #     print('\t 3 \t =',split_acc[3])
    #     return acc, region_acc, split_acc[0], split_acc[1], split_acc[2], split_acc[3]

            