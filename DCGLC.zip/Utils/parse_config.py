import yaml

class ParseConfig:
  @staticmethod
  def parse_yaml(file_path:str):
    with open(file_path, 'r') as f:
      config = yaml.safe_load(f)
    return config

  def __init__(self, config:dict):
    self.config = config

  def __getitem__(self, name):
    """Access items like ordinary dict."""
    para_path = name.split('/')
    res = self.config
    for para in para_path:
      res = res[para]
    return res
  
  
  def init_obj(self, name, module, *args, **kwargs):
      """
      Finds a function handle with the name given as 'type' in config, and returns the
      instance initialized with corresponding arguments given.

      `object = config.init_obj('name', module, a, b=1)`
      is equivalent to
      `object = module.name(a, b=1)`
      """

      # 实现了__getitem__，所以可以有self[name]
      module_name = self[name]['type']
      module_args = dict(self[name]['args']) if 'args' in self[name] else dict()

      module_args.update(kwargs)
      return getattr(module, module_name)(*args, **module_args)

if __name__ == '__main__':
  config = ParseConfig.parse_yaml('DCGLC-main/configs/ieee24.yaml')
  print(config)
