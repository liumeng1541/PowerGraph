import torch
from torch_geometric.data import Data, Dataset
import os

class GridDataset(Dataset):
    def __init__(self, data_list, data_aug_list, device):
        self.data_list = data_list
        self.data_aug_list = data_aug_list
        self.targets = [data.y.item() for data in data_list]
        self.targets = torch.tensor(self.targets).to(device)
        assert len(data_list) == len(data_aug_list), "原图和增强图数量不匹配"

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        return self.data_list[idx], self.data_aug_list[idx], self.targets[idx]