import os

import torch
from tqdm import tqdm
from Utils.util import autocast
from Utils.metric import Metric
import torch.nn.functional as F
import torch
import numpy as np
class Trainer():
    def __init__(self,
                 name,
                 config,  # dict_args
                 contrastive_model, # GNN + 对比学习模型
                 tlc_model, # tlc 可信长尾分类模型
                 criterion,  # loss的计算方式
                 opt,   # optimizer
                 train_data_loader,
                 val_data_loader,
                 lr_scheduler,
                 train_target,
                 val_target,
                 dataset,
                 selected_indices
                ):
        self.selected_indices=selected_indices
        self.config = config
        self.name =  name
        self.log_interval = self.config['log_interval']
        self.device = self.config['device']
        self.contrastive_model = contrastive_model.to(self.device)
        self.tlc_model = tlc_model.to(self.device)
        self.criterion = criterion.to(self.device)
        self.opt = opt
        self.epoch = self.config['epochs']
        self.sample_counts = self.config['sample']
        self.train_data_loader = train_data_loader
        self.data_len = len(self.train_data_loader)
        self.val_data_loader = val_data_loader
        self.lr_scheduler = lr_scheduler
        self.train_target = train_target
        self.val_target = val_target
        self.dataset = dataset
        self.lam = 0.01
        self.num_class = self.val_target.max().item()+1
        pass

    def train(self):
        for epoch in range(1, self.epoch + 1):
            self._train_epoch(epoch)

    def tlc_add(self,A, B, class_weights):
        class_weights = torch.tensor(class_weights, dtype=torch.float32)
        ce_loss = -B * torch.log(A + 1e-10)  
        weighted_ce_loss = class_weights * ce_loss
        sample_loss = torch.sum(weighted_ce_loss, dim=1)
        loss = torch.mean(sample_loss)
        return loss

    def _train_epoch(self, epoch):
        print(f'================ Epoch: {epoch:03d} ================')
        self.contrastive_model.train()
        self.tlc_model.train()
        self.criterion._hook_before_epoch(epoch)
        self.tlc_model._hook_before_iter()
        history_loss = []
        loss_all = 0
        batch = 0
        idx = -1
        for data, data_aug, target in tqdm(self.train_data_loader, desc=f'Epoch: {epoch}'):
                idx = idx + 1
                batch_idx = torch.unique(data.batch) + self.config['batch_size'] * idx
                data=data.to(self.device)
                data_aug=data_aug.to(self.device)
                self.opt.zero_grad()
                node_num, _ = data.x.size()
                # data_batch相当于几号节点属于几号图
                # z是嵌入表示
                z = self.contrastive_model(data.x, data.edge_index, data.batch, data.num_graphs)
                z_aug = self.contrastive_model(data_aug.x, data_aug.edge_index, data_aug.batch, data_aug.num_graphs)
                # 对比学习的损失
                contrastive_loss = self.contrastive_model.loss_cal(z, z_aug)
                output = self.tlc_model(z)
                soft_output = F.softmax(output, dim=1)

                sample_counts = self.sample_counts
                start_index = 0
                total_samples = sum(sample_counts)
                class_weights = torch.tensor([total_samples / count for count in sample_counts],
                                             dtype=torch.float32,
                                             device=self.device)
                one_hot = torch.nn.functional.one_hot(target, self.num_class)
                tlc_add = self.tlc_add(soft_output, one_hot,class_weights)
                extra_info = {
                    "num_expert"    : len(self.tlc_model.backbone.logits)   ,
                    "logits"        : self.tlc_model.backbone.logits        ,
                    'w'             : self.tlc_model.backbone.w
                }
                tlc_loss = self.criterion(
                    x = output,
                    y = target,
                    epoch = epoch,
                    tlc_add=tlc_add,
                    extra_info = extra_info,
                )
                # tlc_aug_loss = self.criterion(
                #     x = output_aug,
                #     y = target,
                #     epoch = epoch,
                #     extra_info = extra_info
                # )
                loss = contrastive_loss +   self.lam*tlc_loss
                loss.backward()

                self.opt.step()
                history_loss.append(loss.item())
        print()
        print(f"loss is: {loss}")
        self._valid_epoch(epoch)

    def _valid_epoch(self, epoch):
        self.contrastive_model.eval()
        self.tlc_model.eval()
        output = torch.empty(0,self.num_class,dtype=torch.float32,device=self.device)
        model_save_dir = 'model_save'
        contrastive_model_path = os.path.join(model_save_dir, self.name, 'contrastive_model_epoch.pth')
        tlc_model_path = os.path.join(model_save_dir, self.name, 'tlc_model_epoch.pth')
        self.contrastive_model.load_state_dict(torch.load(contrastive_model_path, map_location=self.device))
        self.tlc_model.load_state_dict(torch.load(tlc_model_path, map_location=self.device))
        for data, data_aug, target in self.val_data_loader:
            data = data.to(self.device)
            z = self.contrastive_model(data.x, data.edge_index, data.batch, data.num_graphs)
            with torch.no_grad():
                o = self.tlc_model(z)
            output = torch.cat([output, o.detach()],dim=0)
        pred = torch.argmax(output, dim=1)
        Metric.ACC(output, self.val_target)
        Metric.Precision(output, self.val_target)
        Metric.Recall(output, self.val_target)
        Metric.F1_score(output, self.val_target)
        Metric.Each_Class_ACC(output, self.val_target)


