import h5py
import os
import numpy as np
from tqdm import tqdm
import pandas as pd
from collections import Counter
import random
import shutil

memo = {
  'Bf':'_node_labels',
  'blist':'_A',
  'Ef': '_edge_attributes',
  'of_mc':'_graph_labels'
}

toSaveList = ['_A', '_graph_indicator', '_graph_labels', '_node_attributes', '_edge_attributes']
total_selected_count = 10000
random.seed(0)

def convert(dataset_name: str, selected_counts: dict) :
  dir_path = os.path.join('../data', dataset_name,dataset_name)

  # 清空之前的文件
  for item in os.listdir(dir_path):
      item_path = os.path.join(dir_path, item)
      
      if os.path.isfile(item_path):  # 删除文件
          os.remove(item_path)
      elif os.path.isdir(item_path):  # 删除文件夹及其内容
          shutil.rmtree(item_path)

  num_graph = 0

  # 所有图加起来的节点和边数
  total_num_node = 0
  total_num_edge = 0

  # 单个图中的节点数和边数
  graph_num_node = 0  
  graph_num_edge = 0

  # 节点和边的特征数
  node_feature_len = 0
  edge_feature_len = 0

  graph_label = [] # 1 - 4代表4个类比
  node_belong_graph = [] # 每个节点属于哪个图
  edge_belong_node = [] # 每条边连接的两个节点
  total_node_features = [] # 每个节点有3个特征
  total_edge_features = [] # 每个边有4个特征

  selected_indexes = [] # 抽样选取对应的索引下标
  selected_graphs = [] # 抽样选取的图
  selected_node_features = [] # 抽样选取的节点特征
  selected_edge_features = [] # 抽样选取的边特征
  save_path = os.path.join(dir_path, "raw")
  if not os.path.exists(os.path.join(save_path)):
    os.mkdir(save_path)
  
  # 读取图标签
  with h5py.File(os.path.join("Mat" + dataset_name, 'of_mc.mat')) as of_mc:
    oc_mf_ref = of_mc['category'][:][0]
    num_graph = len(oc_mf_ref)
    for iter in tqdm(oc_mf_ref, desc="图标签处理"):
      graph_label.append(np.argmax(of_mc[iter][:].reshape(-1)) + 1)
    
    value_counts = Counter(graph_label)
    total_count = sum(value_counts.values())
    # proportions = {key: count / total_count for key, count in value_counts.items()}
    # 计算每个类别的选取数量
    # selected_counts = {key: selected_num for key in value_counts}

    # current_total = sum(selected_counts.values())
    # print(selected_counts)
    # 四舍五入后，实际选取的数量不严格等于total_selected_count，选择类别最多的进行添加或者删除
    # if current_total != total_selected_count:
    #   difference = total_selected_count - current_total
    #   max_key = max(selected_counts, key = lambda k: proportions[k])
    #   selected_counts[max_key] += difference
    
    for key, count in selected_counts.items():
      # 获取当前类别的所有索引
      class_indexes = [i for i, v in enumerate(graph_label) if v == key]
      # 从中随机选取指定数量的索引
      selected_indexes.extend(random.sample(class_indexes, count))
    selected_indexes.sort()

    selected_graph = [graph_label[i] for i in selected_indexes]

  # 读取节点特征
  with h5py.File(os.path.join("Mat" + dataset_name, 'Bf.mat')) as Bf:
    pos = 0
    idx = 0
    total_node_features_list = []
    Bf_ref = Bf['B_f_tot'][:][0]
    for iter in tqdm(Bf_ref, desc="节点特征处理"):
      graph_node_info = Bf[iter][:].T
      graph_num_node = graph_node_info.shape[0]
      node_feature_len = graph_node_info.shape[1]
      if(idx == selected_indexes[pos]):
        for row in graph_node_info:
          selected_node_features.append(row)
        pos += 1
        if pos == len(selected_indexes):
          break
      idx += 1
    # print(len(selected_node_features))

  # 每个节点确定属于哪个图
  node_belong_graph = [0] * len(selected_graph) * graph_num_node
  for i in tqdm(range(len(node_belong_graph)),desc="节点所属图处理"):
    node_belong_graph[i] = i // graph_num_node + 1

  # 读取边特征
  with h5py.File(os.path.join("Mat" + dataset_name, 'Ef.mat')) as Ef:
    idx = 0
    pos = 0
    Ef_ref = Ef['E_f_post'][:][0]
    for iter in tqdm(Ef_ref, desc="边特征处理"):
      graph_edge_info = Ef[iter][:].T
      graph_num_edge = graph_edge_info.shape[0]
      edge_feature_len = graph_edge_info.shape[1]
      if(idx == selected_indexes[pos]):
        for row in graph_edge_info:
          selected_edge_features.append(row)
        pos += 1
        if pos == len(selected_indexes):
          break
      idx += 1
    # print(len(selected_edge_features))


  # 每条边连接哪两个节点 
  with h5py.File(os.path.join("Mat" + dataset_name, 'blist.mat')) as blist:
    edge_belong_node = [0] * len(selected_graph) * graph_num_edge
    blist_ref = blist['bList'][:].T
    index = 0
    pos = 0
    selected_graph_index = 0
    for graph_index in tqdm(range(num_graph), desc = "确定边的两个端点"):
      if graph_index == selected_indexes[pos]:
        for iter in blist_ref:
          temp = iter.copy()
          temp[0] = temp[0] + graph_num_node * selected_graph_index
          temp[1] = temp[1] + graph_num_node * selected_graph_index
          edge_belong_node[index] = temp
          index = index + 1
        pos = pos + 1
        if pos == len(selected_indexes):
          break
        selected_graph_index = selected_graph_index + 1
    # print((edge_belong_node))
  # # 保存相关的文件

  # 保存抽取了哪些图
  with open(os.path.join(dir_path, "raw", dataset_name + "_selected.txt"), 'w') as f:
    for i in tqdm(range(len(selected_indexes)), desc="保存" + dir_path + "__selected.txt中"):
      f.write(str(int(selected_indexes[i])) + "\n")

  # 保存A.txt
  with open(os.path.join(dir_path, "raw", dataset_name + "_A.txt"), 'w') as f:
    for i in tqdm(range(len(edge_belong_node)), desc="保存" + dir_path + "_A.txt中"):
      f.write(str(int(edge_belong_node[i][0])) + ", " + str(int(edge_belong_node[i][1])) + "\n")

  # 保存graph_indicator.txt
  with open(os.path.join(dir_path, "raw", dataset_name + "_graph_indicator.txt"), 'w') as f:
    for i in tqdm(range(len(node_belong_graph)), desc="保存" + dir_path + "_graph_indicator.txt中"):
      f.write(str(int(node_belong_graph[i])) + "\n")

  # 保存graph_labels.txt
  with open(os.path.join(dir_path, "raw", dataset_name + "_graph_labels.txt"), 'w') as f:
    for i in tqdm(range(len(selected_graph)), desc="保存" + dir_path + "_graph_labels.txt中"):
      f.write(str(int(selected_graph[i])) + "\n")

  # 保存node_attributes.txt
  with open (os.path.join(dir_path, "raw", dataset_name + "_node_attributes.txt"), 'w') as f:
    for i in tqdm(range(len(selected_node_features)), desc="保存" + dir_path + "_node_attributes.txt中"):
      f.write(str(round(selected_node_features[i][0], 4)))
      for j in range(1, node_feature_len):
          f.write(", ")
          f.write(str(round(selected_node_features[i][j], 4)))
      f.write("\n")

  # 保存edge_attributes.txt
  with open (os.path.join(dir_path, "raw", dataset_name + "_edge_attributes.txt"), 'w') as f:
    for i in tqdm(range(len(selected_edge_features)), desc="保存" + dir_path + "_edge_attributes.txt中"):
      f.write(str(round(selected_edge_features[i][0], 4)))
      for j in range(1, edge_feature_len):
          f.write(", ")
          f.write(str(round(selected_edge_features[i][j], 4)))
      f.write("\n")

  print()
  
if __name__ == '__main__':
  selected_counts = {
    # 1：A类；2: B类；3: C类；4: D类
    1: 800,  
    2: 0, 
    3: 1200,
    4: 2400
  }
  convert("uk", selected_counts)


