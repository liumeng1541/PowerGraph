from tqdm import tqdm
import warnings
import scipy

warnings.filterwarnings("ignore")

from arguments import arg_parse
from torch_geometric.loader import DataLoader
from data_loader.TUDataset import TUDataset as TUDataset
from data_loader.GridDataset import GridDataset as GridDataset
from Utils.parse_config import ParseConfig
from sklearn.cluster import KMeans
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from Utils.evaluate_embedding import cluster_acc
from model.contrastive_model import ContrastiveLearningModel
from trainer import Trainer as Trainer
import numpy as np
import os.path as osp
import torch
import torch.nn.functional as F
import scipy
import sys
import signal
import datetime
import random
import model.tlc_model as module_arch
import model.loss as module_loss
import numpy as np
import os

st_time = None


def handler(signum, frame):
    print("程序运行时长:{}秒".format((datetime.datetime.now() - st_time).total_seconds()))
    sys.exit(0)


signal.signal(signal.SIGINT, handler)


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()


def set_seed(seed=None):
    # control randomness
    if seed:
        # random #
        random.seed(seed)
        # hashseed #
        os.environ['PYTHONHASHSEED'] = str(seed)
        # numpy #
        np.random.seed(seed)
        # torch #
        torch.manual_seed(seed)  # torch cpu
        torch.cuda.manual_seed(seed)  # torch current gpu
        torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.
        # GPU计算结果确定
        torch.backends.cudnn.benchmark = False  # ensure CUDA selects the same algorithm each time an application is run
        torch.backends.cudnn.deterministic = True  # Avoiding nondeterministic algorithms
    # torch.set_deterministic(True) # make other PyTorch operations behave deterministically


def load_and_cluster():
    return
    model.load_state_dict(torch.load("./weight/" + args.DS + "_model.pth"))
    model.eval()
    emb, tmp_q, y = model.get_results(dataloader)
    tmp_total = np.maximum(tmp_q, tmp_q)
    y_pred = tmp_total.argmax(1)

    acc = cluster_acc(y, y_pred)
    nmi = nmi_score(y, y_pred)
    ari = ari_score(y, y_pred)

    accmax = acc
    nmimax = nmi
    arimax = ari
    print(accmax)
    with open('./result/' + args.DS + '_result.txt', 'a') as f:
        f.write('Load Saved .pth File' + '\n')
        f.write(args.DS + '_Result:' + '\n')
        f.write('ACC: {:.2f} (0.00)\n'.format(accmax * 100))
        f.write('NMI: {:.2f} (0.00)\n'.format(nmimax * 100))
        f.write('ARI: {:.2f} (0.00)\n'.format(arimax * 100))
        f.write('\n')

    print('Load Saved .pth File for ' + args.DS + '\n')
    print('ACC: {:.2f} (0.00)\n'.format(accmax * 100))
    print('NMI: {:.2f} (0.00)\n'.format(nmimax * 100))
    print('ARI: {:.2f} (0.00)\n'.format(arimax * 100))


if __name__ == '__main__':
    st_time = datetime.datetime.now()
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')
    args = arg_parse()
    print('程序装载完毕开始运行')
    print(args.DS)
    dict_args = ParseConfig.parse_yaml("configs/" + args.DS + ".yaml")
    for key, value in dict_args.items():
        # 只在 args 中没有该键时添加
        if key not in args:
            if not hasattr(args, key):  # 如果 args 没有这个属性
                setattr(args, key, value)  # 动态添加属性
    dict_args['device'] = device
    set_seed(dict_args['seed'])

    path = osp.join(osp.dirname(osp.realpath(__file__)), 'data', args.DS)
    dataset = TUDataset(
        path,
        name=args.DS,
        aug=dict_args['CL']['aug'],
        device=dict_args['device'],
    )

    model_save_dir = 'model_save'
    dataset_path = os.path.join(model_save_dir, args.DS, args.DS+'.pt')
    dataset = torch.load(dataset_path)
    print('------------')
    dict_args['n_labels'] = len(torch.unique(dataset.data.y))
    dict_args['TLC']['arch']['args']['num_classes'] = dict_args['n_labels']
    dict_args['TLC']['arch']['args']['in_planes'] = dict_args['CL']['hidden_dim']
    dict_args['TLC']['arch']['args']['device'] = device
    num_classes = dict_args['TLC']['arch']['args']['num_classes']
    factory = ParseConfig(dict_args)
    random.seed(dict_args['seed'])
    num_to_select = int(dict_args['val_ratio'] * len(dataset.data_list))
    lr = dict_args['optimizer']['args']['lr']
    indices = list(range(len(dataset.data_list)))
    selected_indices = random.sample(indices, num_to_select)
    train_data_list = [dataset.data_list[i] for i in indices if i not in selected_indices]
    train_data_aug_list = [dataset.data_aug_list[i] for i in indices if i not in selected_indices]
    val_data_list = [dataset.data_list[i] for i in selected_indices]
    val_data_aug_list = [dataset.data_aug_list[i] for i in selected_indices]
    train_dataset = GridDataset(train_data_list, train_data_aug_list, device)
    val_dataset = GridDataset(val_data_list, val_data_aug_list, device)
    train_dataloader = DataLoader(train_dataset, batch_size=dict_args['batch_size'], shuffle=False)
    val_dataloader = DataLoader(val_dataset, batch_size=dict_args['batch_size'], shuffle=False)
    hidden_dim = dict_args['CL']['hidden_dim']
    log_interval = args.log_interval
    dataset_num_features = max(dataset.data.num_features, 1)

    contrastive_model = ContrastiveLearningModel(
        dict_args=dict_args,
        dataset_num_features=dataset_num_features,
    ).to(device)
    tlc_model = factory.init_obj('TLC/arch', module_arch)
    # loss_class = getattr(module_loss, dict_args['TLC']["loss"]["type"])

    # optimizer = factory.init_obj(
    #     'optimizer',
    #     torch.optim,
    #     contrastive_model.parameters()
    # )
    cls_num_list = np.histogram(train_dataset.targets.cpu(), bins=num_classes)[0].tolist()
    criterion = factory.init_obj('TLC/loss', module_loss, cls_num_list=cls_num_list)

    optimizer = factory.init_obj(
        'optimizer',
        torch.optim,
        list(contrastive_model.parameters())
        + list(tlc_model.parameters())
    )

    # optimizer = torch.optim.Adam(
    #     list(contrastive_model.parameters()) + list(tlc_model.parameters()),
    #     lr=lr)
    trainer = Trainer(
        name=args.DS,
        config=dict_args,
        contrastive_model=contrastive_model,
        tlc_model=tlc_model,
        criterion=criterion,
        opt=optimizer,
        train_data_loader=train_dataloader,
        val_data_loader=val_dataloader,
        lr_scheduler=None,
        train_target=train_dataset.targets,
        val_target=val_dataset.targets,
        dataset=dataset,
        selected_indices=selected_indices
    )
    if args.eval:
        load_and_cluster()
    else:
        trainer.train()
