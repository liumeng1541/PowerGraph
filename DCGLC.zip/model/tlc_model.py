import torch.nn as nn
import torch.nn.functional as F
from . import ResnetCifar


class Model(nn.Module):
    requires_target = False

    def __init__(self, num_classes, backbone_class=None):
        super().__init__()
        if backbone_class is not None:  # Do not init backbone here if None
            self.backbone = backbone_class(num_classes)

    def _hook_before_iter(self):
        self.backbone._hook_before_iter()

    def forward(self, x):
        self.backbone(x)
        return self.projector(x)


class ResNet32Model(Model):
    def __init__(
            self,
            num_classes,
            num_experts,
            in_planes,
            out_planes,
            block_num,
            reweight_temperature,
            device,
            **kwargs
    ):
        super().__init__(num_classes, None)
        self.backbone = ResnetCifar.ResNet_s(
            block=ResnetCifar.BasicBlock,
            num_classes=num_classes,
            num_experts=num_experts,
            in_planes=in_planes,
            out_planes=out_planes,
            block_num=block_num,
            reweight_temperature=reweight_temperature,
            device=device,
            **kwargs
        )
        self.projector = nn.Sequential(
            nn.Linear(in_planes, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256, num_classes)
        )
