import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
from torch.nn import Parameter
import random

# 正太分布初始化系数
def _weights_init(m):
    classname = m.__class__.__name__
    if isinstance(m, nn.Linear) or isinstance(m, nn.Conv1d):
        
        init.kaiming_normal_(m.weight)

# 专家系统的一部分
class NormedLinear(nn.Module):
    def __init__(self,in_features,out_features):
        super(NormedLinear, self).__init__()
        self.weight = Parameter(torch.Tensor(in_features, out_features))
        self.weight.data.uniform_(-1, 1).renorm_(2, 1, 1e-5).mul_(1e5)
    def forward(self, x):
        return F.normalize(x,dim=1).mm(F.normalize(self.weight,dim=0))

# 专家系统的一部分，残差网络
class BasicBlock(nn.Module):
    def __init__(self, in_planes, out_planes, device):
        super(BasicBlock, self).__init__()
        self.linear = nn.Linear(in_planes, out_planes).to(device)
        self.shortcut = nn.Identity()
        if in_planes != out_planes:
            self.shortcut = nn.Linear(in_planes, out_planes, bias = False).to(device)
    
    def forward(self, x):
        out = F.relu(self.linear(x))
        out = out + self.shortcut(x)
        return out

class ResNet_s(nn.Module):

    def __init__(
            self,block,
            num_experts,
            num_classes,
            in_planes,
            out_planes,
            block_num,
            reweight_temperature,
            device
        ):
        super(ResNet_s,self).__init__()
        self.num_classes = num_classes
        self.num_experts = num_experts
        self.eta = reweight_temperature
        self.device = device
        # 当前线性层的输入维度
        self.in_planes = in_planes
        self.out_planes = out_planes
        self.block_num = block_num
        self.layers = nn.ModuleList()
        self.cluster_projector_t = nn.Sequential(
            nn.Linear(self.in_planes, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256, self.num_classes),
            nn.Softmax(dim=1)
        )
        # 线性层组成一个专家系统
        # for i in range(num_experts):
        #     setattr(self, 'linear{}'.format(i), BasicBlock(self.in_planes, self.out_planes, self.device))
        # self.linear = nn.Linear(self.out_planes[-1], self.num_classes).to(self.device)
        in_planes = self.in_planes
        # 线性层组成一个专家系统
        for i in range(num_experts):
            inner1_layers = nn.ModuleList()
            in_planes = self.in_planes
            for j in range(len(block_num)):
                inner2_layers = nn.ModuleList(self._make_layer(block, in_planes, self.out_planes[j], self.device, self.block_num[j]))
                in_planes = self.out_planes[j]
                inner1_layers.append(inner2_layers)            
            self.layers.append(inner1_layers)
            # self.layer2s = nn.ModuleList([self._make_layer(block, self.in_planes, self.out_planes) for _ in range(num_experts)])        
            # self.layer3s = nn.ModuleList([self._make_layer(block,self.in_planes,self.out_planes) for _ in range(num_experts)])
  
        self.linears = nn.ModuleList([NormedLinear(self.out_planes[-1], num_classes) for _ in range(num_experts)])
        
        self.use_experts = list(range(num_experts))
        self.apply(_weights_init)

    def _make_layer(self, block, in_features, out_features, device, num):
        blocks = nn.ModuleList()
        for i in range(num):
            blocks.append(block(in_features, out_features, device))
            in_features = out_features
        return blocks

    def _hook_before_iter(self):
        assert self.training, "_hook_before_iter should be called at training time only, after train() is called"
        # 现在的模型就没有nn.BatchNorm1d了
        # for module in self.modules():
        #     if isinstance(module, nn.BatchNorm1d):
        #         if not module.weight.requires_grad:
        #             module.eval()

    def forward(self,x):
        # x = F.relu(self.bn1(self.conv1(x)))
        outs = []
        self.logits = outs
        b0 = None
        self.w = [torch.ones(len(x),dtype=torch.bool,device=x.device)]
        for i in range(len(self.use_experts)):
            xi = x
            for layer in self.layers[i]:
                for block in layer:
                    xi = block(xi)
                    pass
                # xi = self.layer2s[i](xi)
                # xi = self.layer3s[i](xi)
                # # xi = F.avg_pool1d(xi,xi.shape[3])
                # xi = F.avg_pool1d(xi,xi.shape[2])
                # xi = xi.flatten(1)
            xi = self.linears[i](xi)
            # 这行也算是个超参
            # xi = xi * 30
            # xi = xi * 10
            outs.append(xi)

            # evidential
            alpha = torch.exp(xi)+1
            S = alpha.sum(dim=1,keepdim=True)
            b = (alpha-1)/S
            u = self.num_classes/S.squeeze(-1)

            # update w
            if b0 is None:
                C = 0
            else:
                bb = b0.view(-1,b0.shape[1],1)@b.view(-1,1,b.shape[1])
                C = bb.sum(dim=[1,2])-bb.diagonal(dim1=1,dim2=2).sum(dim=1)
            b0 = b
            self.w.append(self.w[-1]*u/(1-C))

        # dynamic reweighting
        exp_w = [torch.exp(wi/self.eta) for wi in self.w]
        exp_w = [wi/wi.sum() for wi in exp_w]
        exp_w = [wi.unsqueeze(-1) for wi in exp_w]

        reweighted_outs = [outs[i]*exp_w[i] for i in self.use_experts]
        res = sum(reweighted_outs)
        return res
