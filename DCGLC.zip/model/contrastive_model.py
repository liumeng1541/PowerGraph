import numpy as np
import torch
import torch.nn as nn
from torch.nn.parameter import Parameter

from Utils.Constraint import *
from model.gin import Encoder


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()


class ContrastiveLearningModel (nn.Module):
    def __init__(self, dict_args, dataset_num_features, alpha=1.0):
        super(ContrastiveLearningModel, self).__init__()
        self.alpha = alpha
        self.device = dict_args['device']
        self.n_labels = dict_args['n_labels']
        self.tau = dict_args['CL']['tau']
        self.encoder = encoder(dict_args, dataset_num_features, self.n_labels)

        

    # n_aug目前没用到
    def forward(self, x, edge_index, batch, num_graphs, n_aug=0):
        if x is None or len(x.shape) == 1 or x.shape[1] == 0:
            x = torch.ones(batch.shape[0]).to(self.device)

        # z是聚类的嵌入空间表示，y应该是GNN后经过MLP的嵌入空间表示，y没什么用
        z = self.encoder(x, edge_index, batch, num_graphs)

        return z


    # 计算对比学习损失, 这里和论文中的不一样，论文中是低维中计算，这里直接原始维度计算了
    def loss_cal(self, x, x_aug):
        T = self.tau
        batch_size, _, = x.size()
        x_abs = x.norm(dim=1)
        x_aug_abs = x_aug.norm(dim=1)
        sim_matrix = torch.einsum('ik,jk->ij', x, x_aug) / torch.einsum('i,j->ij', x_abs, x_aug_abs)
        sim_matrix = torch.exp(sim_matrix / T)
        pos_sim = sim_matrix[range(batch_size), range(batch_size)]
        loss = pos_sim / (sim_matrix.sum(dim=1) - pos_sim)
        loss = - torch.log(loss).mean()
        return loss


# 没用到
EPS = 1e-15
def loss_balance_entropy(prob, *kwargs):
    prob = prob.clamp(EPS)
    entropy = prob * prob.log()

    # return negative entropy to maximize it
    if entropy.ndim == 1:
        return entropy.sum()
    elif entropy.ndim == 2:
        return entropy.sum(dim=1).mean()
    else:
        raise ValueError(f'Probability is {entropy.ndim}-d')


class encoder(nn.Module):
    def __init__(self, dict_args, dataset_num_features, device, alpha=1.0):
        super(encoder, self).__init__()
        self.alpha = alpha
        self.device = device
        self.tau = dict_args['CL']['tau']
        self.hidden_dim = dict_args['CL']['hidden_dim']
        self.num_gc_layers = dict_args['CL']['num_gc_layers']
        # GNN考虑了每一层的输出，所以乘上了nun_gc_layers
        # self.embedding_dim = mi_units = dict_args['CL']['hidden_dim'] * dict_args['CL']['num_gc_layers']
        
        # 将GNN中每一层的输出当作一个channel，所以不需要乘上num_gc_layers
        self.embedding_dim = mi_units = self.hidden_dim

        # GIN encoder
        self.encoder = Encoder(
            dataset_num_features, 
            self.hidden_dim,
            self.num_gc_layers,
            self.device
        )

        # n_aug没用到，目前只用到了self.proj_head[0]
        self.proj_head = nn.Sequential(nn.Linear(self.embedding_dim, self.embedding_dim),
                                                      nn.LeakyReLU(inplace=False),
                                                      nn.Linear(self.embedding_dim, self.embedding_dim))
        
        self.mlp = MLP(self.embedding_dim)
        self.init_emb()

    # 初始化线性层系数
    def init_emb(self):
        initrange = -1.5 / self.embedding_dim
        for m in self.modules():
            if isinstance(m, nn.Linear):
                torch.nn.init.xavier_uniform_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.fill_(0.0)

    def forward(self, x, edge_index, batch, num_graph, n_aug=0):

        if x is None or len(x.shape) == 1 or x.shape[1] == 0:
            x = torch.ones(batch.shape[0])

        # 进行了GIN
        y = self.encoder(x, edge_index, batch)

        # proj_head可以认为就是走了个MLP
        y = self.proj_head(y)

        # 这个也可以理解为MLP的一部分
        g_enc = self.mlp(y)    
        return g_enc


# 前馈神经网络加上残差连接
class MLP(nn.Module):
    def __init__(self, input_dim):
        super().__init__()

        self.block = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Linear(input_dim, input_dim),

            nn.ReLU(),
            nn.Linear(input_dim, input_dim),

            nn.ReLU()
        )
        self.linear_shortcut = nn.Linear(input_dim, input_dim)

 
    def forward(self, x):
        return self.block(x) + self.linear_shortcut(x)