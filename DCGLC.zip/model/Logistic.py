import torch
import torch.nn as nn
import torch.optim as optim

class LogisticRegression(nn.Module):
    def __init__(self, input_dim, num_classes):
        super(LogisticRegression, self).__init__()
        self.linear = nn.Linear(input_dim, num_classes)  # 线性层

    def forward(self, x):
        return torch.sigmoid(self.linear(x))  # 使用 sigmoid 转换为概率